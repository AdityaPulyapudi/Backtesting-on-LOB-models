import numpy as np

dec_data = np.loadtxt('C:\\Users\\SAI CHARAN\\OneDrive\\Desktop\\proj\\Train_Dst_NoAuction_DecPre_CF_7.txt')

dec_train = dec_data[:, :int(np.floor(dec_data.shape[1] * 0.8))]
dec_val = dec_data[:, int(np.floor(dec_data.shape[1] * 0.8)):]

dec_test1 = np.loadtxt('C:\\Users\\SAI CHARAN\\OneDrive\\Desktop\\proj\\Test_Dst_NoAuction_DecPre_CF_7.txt')
dec_test2 = np.loadtxt('C:\\Users\\SAI CHARAN\\OneDrive\\Desktop\\proj\\Test_Dst_NoAuction_DecPre_CF_8.txt')
dec_test3 = np.loadtxt('C:\\Users\\SAI CHARAN\\OneDrive\\Desktop\\proj\\Test_Dst_NoAuction_DecPre_CF_9.txt')
dec_test = np.hstack((dec_test1, dec_test2, dec_test3))

print(dec_data.shape)
print(dec_train.shape)
print(dec_val.shape)
print(dec_test.shape)

def prepare_x(data):
    df1 = data[:40, :].T
    return np.array(df1)

def get_label(data):
    lob = data[-5:, :].T
    return lob

def data_classification(X, Y, T):
    [N, D] = X.shape
    df = np.array(X)
    dY = np.array(Y)
    dataY = dY[T - 1:N]
    dataX = np.zeros((N - T + 1, T, D))
    for i in range(T, N + 1):
        dataX[i - T] = df[i - T:i, :]
    return dataX.reshape(dataX.shape + (1,)), dataY

def prepare_x_y(data, k, T):
    x = prepare_x(data)
    y = get_label(data)
    x, y = data_classification(x, y, T=T)
    y = y[:,k] - 1
    y = to_categorical(y, 3)
    return x, y