from flask import Flask, render_template, request, redirect, url_for,Response
import time
import json
import numpy as np
pred = np.load('pred.npy')
testX_CNN = np.load('testX_CNN.npy')

app = Flask(__name__)

index = 0
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/submit_number', methods=['POST'])
def submit_number():
    global money
    money = int(request.form['number'])
    return render_template('result.html')


@app.route('/data')
def data():
    def generate_numbers():   
        global index
        num_shares = 0
        mid_price = 0
        x = money
        # 0-hold
        # 1-sold
        # 2-bought
        while index<len(testX_CNN):
            opt_to=0
            predicted_label = np.zeros_like(pred[index])
            predicted_label[np.argmax(pred[index])] = 1
            mid_price = (testX_CNN[index][0][0]+testX_CNN[index][0][0])/2

            if predicted_label[2]==1:
               if(num_shares) :
                  x = num_shares*mid_price
                  num_shares = 0
                  opt_to=1
            else :
               if(x!=0):
                  num_shares = x/mid_price
                  x = 0
                  opt_to=2

            yield 'data: {}\n\n'.format(json.dumps({'number': int(max(x,num_shares*mid_price)),'opt_to':opt_to}))
            index += 200  # taking decision for every 10 seconds
            time.sleep(1)
    return Response(generate_numbers(), mimetype='text/event-stream')

if __name__ == '__main__':
    app.run(debug=True)
